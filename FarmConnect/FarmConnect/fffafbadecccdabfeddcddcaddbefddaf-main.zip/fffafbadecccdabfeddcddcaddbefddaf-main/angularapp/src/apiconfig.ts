export const apiUrl = 'https://8080-fffafbadecccdabfeddcddcaddbefddaf.premiumproject.examly.io';
