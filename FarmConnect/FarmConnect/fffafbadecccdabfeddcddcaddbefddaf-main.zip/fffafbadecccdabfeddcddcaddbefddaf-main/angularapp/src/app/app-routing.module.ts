import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './components/error/error.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuard } from './components/authguard/auth.guard';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { CreatemedicineComponent } from './components/createmedicine/createmedicine.component';
import { ViewmedicineComponent } from './components/viewmedicine/viewmedicine.component';
import { SuppliereditmedicineComponent } from './components/suppliereditmedicine/suppliereditmedicine.component';
import { CreatefeedComponent } from './components/createfeed/createfeed.component';
import { ViewfeedComponent } from './components/viewfeed/viewfeed.component';
import { SuppliereditfeedComponent } from './components/suppliereditfeed/suppliereditfeed.component';
import { OwnerviewmedicineComponent } from './components/ownerviewmedicine/ownerviewmedicine.component';
import { RequestformComponent } from './components/requestform/requestform.component';
import { OwnerviewfeedComponent } from './components/ownerviewfeed/ownerviewfeed.component';
import { ViewlivestockComponent } from './components/viewlivestock/viewlivestock.component';
import { CreatelivestockComponent } from './components/createlivestock/createlivestock.component';
import { OwnereditlivestockComponent } from './components/ownereditlivestock/ownereditlivestock.component';
import { OwnerviewrequestComponent } from './components/ownerviewrequest/ownerviewrequest.component';
import { SupplierrequestsComponent } from './components/supplierrequests/supplierrequests.component';

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'login', component: LoginComponent },
  {path: 'signup', component: RegistrationComponent },
  {path: 'error', component: ErrorComponent },
  {path: 'supplier/add/newmedicine', component: CreatemedicineComponent, canActivate: [AuthGuard]},
  {path: 'supplier/view/medicine', component: ViewmedicineComponent, canActivate: [AuthGuard]},
  {path: 'owner/view/medicine', component: OwnerviewmedicineComponent, canActivate: [AuthGuard]},
  {path: 'supplier/edit/medicine/:id', component: SuppliereditmedicineComponent, canActivate: [AuthGuard]},
  {path: 'supplier/add/newfeed', component: CreatefeedComponent, canActivate: [AuthGuard]},
  {path: 'supplier/view/feed', component: ViewfeedComponent, canActivate: [AuthGuard]},
  {path: 'owner/view/livestocks', component: ViewlivestockComponent, canActivate: [AuthGuard]},
  {path: 'owner/add/livestock', component: CreatelivestockComponent, canActivate: [AuthGuard]},
  {path: 'owner/edit/livestock/:id', component: OwnereditlivestockComponent, canActivate: [AuthGuard]},
  {path: 'owner/view/feed', component: OwnerviewfeedComponent, canActivate: [AuthGuard]},
  {path: 'owner/view/myrequests', component: OwnerviewrequestComponent, canActivate: [AuthGuard]},
  {path: 'supplier/view/requests', component: SupplierrequestsComponent, canActivate: [AuthGuard]},
  {path: 'supplier/edit/feed/:id', component: SuppliereditfeedComponent, canActivate: [AuthGuard]},
  {path: 'owner/requestform', component: RequestformComponent , canActivate: [AuthGuard]},
  {path :'admin/view/feedback', component: AdminviewfeedbackComponent, canActivate: [AuthGuard]},
  {path :'user/view/feedback', component: UserviewfeedbackComponent, canActivate: [AuthGuard]},
  {path :'user/add/feedback', component: UseraddfeedbackComponent, canActivate: [AuthGuard]},
  { path: '**', redirectTo: '/error' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
