import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { ErrorComponent } from './components/error/error.component';
import { HttpClientModule } from '@angular/common/http';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CommonModule } from '@angular/common';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { CreatemedicineComponent } from './components/createmedicine/createmedicine.component';
import { ViewmedicineComponent } from './components/viewmedicine/viewmedicine.component';
import { SuppliereditmedicineComponent } from './components/suppliereditmedicine/suppliereditmedicine.component';
import { CreatefeedComponent } from './components/createfeed/createfeed.component';
import { ViewfeedComponent } from './components/viewfeed/viewfeed.component';
import { SuppliereditfeedComponent } from './components/suppliereditfeed/suppliereditfeed.component';
import { OwnerviewmedicineComponent } from './components/ownerviewmedicine/ownerviewmedicine.component';
import { RequestformComponent } from './components/requestform/requestform.component';
import { OwnerviewfeedComponent } from './components/ownerviewfeed/ownerviewfeed.component';
import { ViewlivestockComponent } from './components/viewlivestock/viewlivestock.component';
import { CreatelivestockComponent } from './components/createlivestock/createlivestock.component';
import { OwnereditlivestockComponent } from './components/ownereditlivestock/ownereditlivestock.component';
import { OwnerviewrequestComponent } from './components/ownerviewrequest/ownerviewrequest.component';
import { SupplierrequestsComponent } from './components/supplierrequests/supplierrequests.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    ErrorComponent,
    NavbarComponent,
    AdminviewfeedbackComponent,
    UserviewfeedbackComponent,
    UseraddfeedbackComponent,
    AdminnavComponent,
    UsernavComponent,
    CreatemedicineComponent,
    ViewmedicineComponent,
    SuppliereditmedicineComponent,
    CreatefeedComponent,
    ViewfeedComponent,
    SuppliereditfeedComponent,
    OwnerviewmedicineComponent,
    RequestformComponent,
    OwnerviewfeedComponent,
    ViewlivestockComponent,
    CreatelivestockComponent,
    OwnereditlivestockComponent,
    OwnerviewrequestComponent,
    SupplierrequestsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
