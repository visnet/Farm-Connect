import { Component, OnInit, ViewChild } from '@angular/core';

import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Feed } from 'src/app/models/feed.model';
import { FeedService } from 'src/app/services/feed.service';

@Component({
  selector: 'app-createfeed',
  templateUrl: './createfeed.component.html',
  styleUrls: ['./createfeed.component.css'],
})
export class CreatefeedComponent implements OnInit {
  @ViewChild('imageInput') imageInput;
  formData: Feed = {
    FeedName: '',
    Type: '',
    Description: '',
    Quantity: null,
    Unit: '',
    PricePerUnit: null,
    Image: '',
    UserId: Number(localStorage.getItem('userId')) || 0,
  };
  errors: any = {};
  errorMessage: string;
  successPopup: boolean = false;

  constructor(private feedService: FeedService, private router: Router) {}

  ngOnInit(): void {
    console.log('User ID:', localStorage.getItem('userId'));
  }

  handleChange(event: any, field: string) {
    this.formData[field] = event.target.value;
  }

  handleFileChange(event: any): void {
    const file = event.target.files[0];

    if (file) {
      this.convertFileToBase64(file).then(
        (base64String) => {
          this.formData.Image = base64String;
        },
        (error) => {
          console.error('Error converting file to base64:', error);
        }
      );
    }
  }

  convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        resolve(reader.result as string);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  onSubmit(feedForm: NgForm) {
    if (feedForm.valid) {
      this.feedService.addFeed(this.formData).subscribe(
        (res) => {
          this.successPopup = true;
          console.log('Feed added successfully', res);
          feedForm.resetForm();
        },
        (err) => {
          this.errorMessage = err.error.message;
          console.error('Error adding feed:', err.error.message);
        }
      );
    } else {
      this.errorMessage = 'All fields are required';
    }
  }

  handleSuccessMessage() {
    this.successPopup = false;
    this.errorMessage = '';
    this.formData = {
      FeedName: '',
      Type: '',
      Description: '',
      Quantity: 0,
      Unit: '',
      PricePerUnit: 0,
      Image: '',
      UserId: Number(localStorage.getItem('userId')) || 0,
    };
    this.imageInput.nativeElement.value = '';
  }
}
