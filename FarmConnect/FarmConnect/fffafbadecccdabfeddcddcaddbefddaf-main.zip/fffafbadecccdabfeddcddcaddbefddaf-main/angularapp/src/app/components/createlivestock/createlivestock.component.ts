import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Livestock } from 'src/app/models/livestock.model';
import { LivestockService } from 'src/app/services/livestock.service';

@Component({
  selector: 'app-createlivestock',
  templateUrl: './createlivestock.component.html',
  styleUrls: ['./createlivestock.component.css']
})
export class CreatelivestockComponent implements OnInit {
  // @ViewChild('imageInput') imageInput;
  formData: Livestock = {
    LivestockId: 0,
    Name: '',
    Species: '',
    Age: null,
    Breed: '',
    HealthCondition: '',
    Location: '',
    VaccinationStatus: '',
    UserId: Number(localStorage.getItem('userId')) || 0,
  };
  errors: any = {};
  errorMessage: string;
  successPopup: boolean = false;

  constructor(private livestockService: LivestockService, private router: Router) {}

  ngOnInit(): void {
    console.log('User ID:', localStorage.getItem('userId'));
  }

  handleChange(event: any, field: string) {
    this.formData[field] = event.target.value;
  }

  handleFileChange(event: any): void {
    const file = event.target.files[0];

    if (file) {
      this.convertFileToBase64(file).then(
        (base64String) => {
          // this.formData.Image = base64String;
        },
        (error) => {
          console.error('Error converting file to base64:', error);
        }
      );
    }
  }

  convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        resolve(reader.result as string);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  onSubmit(livestockForm: NgForm) {
    if (livestockForm.valid) {
      this.livestockService.addLivestock(this.formData).subscribe(
        (res) => {
          this.successPopup = true;
          console.log('Livestock added successfully', res);
          livestockForm.resetForm();
        },
        (err) => {
          this.errorMessage = err.error.message;
          console.error('Error adding livestock:', err.error.message);
        }
      );
    } else {
      this.errorMessage = 'All fields are required';
    }
  }

  handleSuccessMessage() {
    this.successPopup = false;
    this.errorMessage = '';
    this.formData = {
      LivestockId: 0,
      Name: '',
      Species: '',
      Age: null,
      Breed: '',
      HealthCondition: '',
      Location: '',
      VaccinationStatus: '',
      UserId: Number(localStorage.getItem('userId')) || 0,
    };
    this.router.navigate(['/owner/view/livestocks']);
    // this.imageInput.nativeElement.value = '';
  }

}
