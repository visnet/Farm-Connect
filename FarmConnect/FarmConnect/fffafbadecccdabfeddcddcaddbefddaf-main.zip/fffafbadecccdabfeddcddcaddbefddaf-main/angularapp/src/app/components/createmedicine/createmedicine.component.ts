import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Medicine } from 'src/app/models/medicine.model';
import { MedicineService } from 'src/app/services/medicine.service';


@Component({
  selector: 'app-createmedicine',
  templateUrl: './createmedicine.component.html',
  styleUrls: ['./createmedicine.component.css'],
})

export class CreatemedicineComponent implements OnInit {
  @ViewChild('imageInput') imageInput;
  id: string;
  formData: Medicine = { // Use the Medicine interface to type the formData objects
    MedicineName: '',
    Brand: '',
    Category: '',
    Description: '',
    Quantity: 0,
    Unit: '',
    PricePerUnit: 0,
    Image: '',
    UserId: Number(localStorage.getItem('userId')) || 0,

  };
  errors: any = {};
  errorMessage: string;
  successPopup: boolean = false;

  constructor(private medicineService: MedicineService, private router: Router) {}

  ngOnInit(): void {
    // Initialize your component
    console.log('User ID:', localStorage.getItem('userId'));
  }

  handleChange(event: any, field: string) {
    this.formData[field] = event.target.value;
    // Validate your form here and set errors if any
  }

  handleFileChange(event: any): void {
    const file = event.target.files[0];

    if (file) {
      this.convertFileToBase64(file).then(
        (base64String) => {
          this.formData.Image = base64String;
        },
        (error) => {
          console.error('Error converting file to base64:', error);
          // Handle error appropriately
        }
      );
    }
  }

  convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        resolve(reader.result as string);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }


  onSubmit(medicineForm: NgForm) {
    console.log('Form Validity:', medicineForm.valid);
    if (medicineForm.valid) {
      this.medicineService.addMedicine(this.formData).subscribe(
        (res) => {
          this.successPopup = true;
          console.log('Medicine added successfully', res);
          medicineForm.resetForm();
        },
        (err) => {
          this.errorMessage = err.error.message;
          console.error('Error adding medicine:', err);
        }
      );
    } else {
      this.errorMessage = 'All fields are required';
    }
  }

  handleSuccessMessage() {
    this.successPopup = false;
    this.errorMessage = '';
    this.formData = {
      MedicineName: '',
      Brand: '',
      Category: '',
      Description: '',
      Quantity: 0,
      Unit: '',
      PricePerUnit: 0,
      Image: '',
      UserId: Number(localStorage.getItem('userId')) || 0,
    };
    this.imageInput.nativeElement.value = '';
  }
}
