import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Livestock } from 'src/app/models/livestock.model';
import { LivestockService } from 'src/app/services/livestock.service';

@Component({
  selector: 'app-ownereditlivestock',
  templateUrl: './ownereditlivestock.component.html',
  styleUrls: ['./ownereditlivestock.component.css']
})
export class OwnereditlivestockComponent implements OnInit {

  id: number;
  errorMessage: string = '';
  formData: Livestock = {
    LivestockId: 0,
    Name: '',
    Species: '',
    Age: null,
    Breed: '',
    HealthCondition: '',
    Location: '',
    VaccinationStatus: '',
    UserId: null
  };
  errors: any = {};
  successPopup: boolean; // Add this line to declare the successPopup property

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private livestockService: LivestockService
  ) {}

  ngOnInit(): void {
    console.log("Hello");
    this.id = parseInt(this.route.snapshot.paramMap.get('id'));
    this.getLivestockById();
  }

  getLivestockById() {
    this.livestockService.getLivestockByID(this.id).subscribe(
      (response) => {
        console.log('Livestock details:', response);
        this.formData = {
          LivestockId: response.LivestockId,
          Name: response.Name,
          Species: response.Species,
          Age: response.Age,
          Breed: response.Breed,
          HealthCondition: response.HealthCondition,
          Location: response.Location,
          VaccinationStatus: response.VaccinationStatus,
          UserId: response.UserId
        };
      },
      (error) => {
        console.error('Error fetching livestock details:', error);
        this.router.navigate(['/error']);
      }
    );
  }

  handleChange(event: any, field: string) {
    this.formData[field] = event.target.value;
    this.errors[field] = ''; // Clear error when the user makes a change
  }

  handleUpdateLivestock(livestockForm: NgForm) {
    if (livestockForm.valid) {
      this.livestockService.updateLivestock(this.id, this.formData).subscribe(
        (response) => {
          console.log('Livestock updated successfully', response);
          this.successPopup = true;
          this.errorMessage = '';
        },
        (error) => {
          console.error('Error updating livestock:', error);
          this.errorMessage = error.error.message;
        }
      );
    }
  }

  handleFileChange(event: any): void {
    const file = event.target.files[0];

    if (file) {
      this.convertFileToBase64(file).then(
        (base64String) => {
          // this.formData.Image = base64String;
        },
        (error) => {
          console.error('Error converting file to base64:', error);
          // Handle error appropriately
        }
      );
    }
  }

  convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        resolve(reader.result as string);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  handleOkClick() {
    // Close the success popup
    this.successPopup = false;
    this.router.navigate(['/owner/view/livestocks']);
  }

  navigateToDashboard() {
    this.router.navigate(['/owner/view/livestocks']);
  }

}
