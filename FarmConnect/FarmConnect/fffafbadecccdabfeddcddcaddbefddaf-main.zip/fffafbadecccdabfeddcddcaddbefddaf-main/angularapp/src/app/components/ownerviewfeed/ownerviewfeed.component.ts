import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { FeedService } from 'src/app/services/feed.service';

@Component({
  selector: 'app-ownerviewfeed',
  templateUrl: './ownerviewfeed.component.html',
  styleUrls: ['./ownerviewfeed.component.css']
})
export class OwnerviewfeedComponent implements OnInit {

  availableLoans: any[] = [];
  filteredLoans = [];
  searchValue: string = '';
  sortValue: number = 0;
  page: number = 1;
  limit: number = 5;
  appliedLoans: any[] = [];
  loans = [];
  showRequestForm = false;
  successPopup = false;
  selectedFeed: any = null;
  filteredMedicines: any[] = []; // Assuming this is populated with the list of medicines



  constructor(private router: Router, private feedService: FeedService) {}

  ngOnInit(): void {
    this.fetchData();
  }

  //  fetchAppliedLoans() {

  //   const userId = localStorage.getItem('userId');
  //   this.feedService.getAppliedLoans(userId).subscribe(
  //     (response: any) => {
  //       this.appliedLoans = response;
  //       console.log('Applied loans:', this.appliedLoans);
  //     },
  //     (error) => {
  //       console.error('Error fetching data:', error);
  //     }
  //   );
  // }

  fetchData() {
    const userId = localStorage.getItem('userId');

    forkJoin({
      // appliedLoans: this.feedService.getAppliedLoans(userId),
      allMedicines: this.feedService.getAllFeed()
    }).subscribe(
      ({ allMedicines }) => {
        // ({ appliedLoans, allLoans }) => {
        // this.appliedLoans = appliedLoans;
        this.availableLoans = allMedicines;
        this.filteredLoans = allMedicines;
        this.filteredMedicines = allMedicines;
        console.log('Applied loans:', this.appliedLoans);
        console.log('Available loans:', this.availableLoans);
      },
      (error) => {
        console.error('Error fetching data:', error);
      }
    );
  }

  // async fetchData() {
  //      this.fetchAppliedLoans();

  //   this.feedService.getAllLoans().subscribe(
  //     (data: any) => {
  //       this.availableLoans = data;
  //       this.filteredLoans = data;
  //       console.log('Available loans:', this.availableLoans);
  //     },
  //     (error) => {
  //       // Handle error
  //       console.error('Error fetching loans:', error);
  //     }
  //   );
  // }

  searchField = '';

  handleSearchChange(searchValue: string): void {
    this.searchField = searchValue;
    console.log('searchValue:', searchValue);

    this.filteredLoans = this.filterLoans(searchValue);
  }

  filterLoans(search: string) {
    const searchLower = search.toLowerCase();
    if (searchLower === '') return this.availableLoans;
    console.log('searchLower:', searchLower);
    console.log('availableLoans:', this.availableLoans);


    return this.availableLoans.filter(
      (loan) =>
        loan.MedicineName.toLowerCase().includes(searchLower) ||
        // loan.MedicineType.toLowerCase().includes(searchLower) ||
        loan.Description.toLowerCase().includes(searchLower)

        // loan.LoanType.toLowerCase().includes(searchLower) ||
        // loan.Description.toLowerCase().includes(searchLower)
    );
  }

  toggleSort(order: number) {
    this.sortValue = order;

    this.filteredLoans = [...this.filteredLoans].sort((a, b) => {
      if (order === 1) {
        return a.interestRate - b.interestRate;
      } else if (order === -1) {
        return b.interestRate - a.interestRate;
      } else {
        return 0;
      }
    });
  }

  handleApplyClick(medicine: any): void {
    console.log('Medicine:', medicine);
    this.showRequestForm = true;
    this.selectedFeed = medicine;
  }
  handleFormSubmitted(): void {
    this.successPopup = true;
    this.showRequestForm = false;
    this.selectedFeed = null;
  }

  handleFormCancelled(): void {
    this.showRequestForm = false;
    this.selectedFeed = null;
  }

  handleSuccessMessage(): void {
    this.successPopup = false;
    this.router.navigate(['/owner/view/feed']);
  }

  navigateBack(): void {
    this.router.navigate(['/owner/view/feed']); // Navigate to the desired route
  }

  isMedicineRequested(medicine: any): boolean {
    // Implement logic to check if the medicine has already been requested
    return false;
  }

  // handleApplyClick(loan: any) {

  //   const isLoanApplied = this.isLoanApplied(loan);
  //   console.log(isLoanApplied);

  //   if (isLoanApplied) {
  //     alert('Loan is already applied.');
  //   } else {
  //     this.appliedLoans.push(loan);
  //     console.log("selectedloan" ,loan) ;// Add the applied loan to the appliedLoans array
  //     localStorage.setItem('loanId', loan.MedicineId); // Store loanType in local storage
  //     this.router.navigate(['/owner/requestform']);
  //   }
  // }

  get totalPages(): number {
    return Math.ceil(this.filteredLoans.length / this.limit);
  }

  // isLoanApplied(loan: any): boolean {
  //   console.log();
  //   return this.appliedLoans.some(
  //     (appliedLoan) => appliedLoan.loanType === loan.loanType
  //   );
  // }

  isLoanApplied(loan: any): boolean {
    return this.appliedLoans.some(
      (appliedLoan) => appliedLoan.LoanId === loan.LoanId
    );
}

  navigateToViewAppliedLoan() {
    this.router.navigate(['/appliedloan']);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }


}
