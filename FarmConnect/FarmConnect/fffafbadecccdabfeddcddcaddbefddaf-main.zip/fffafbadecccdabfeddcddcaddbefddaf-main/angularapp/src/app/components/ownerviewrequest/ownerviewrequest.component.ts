import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-ownerviewrequest',
  templateUrl: './ownerviewrequest.component.html',
  styleUrls: ['./ownerviewrequest.component.css']
})
export class OwnerviewrequestComponent implements OnInit {

  showDeletePopup = false;
  requestToDelete: any = null;
  userRequests: any[] = [];
  filteredRequests: any[] = [];
  searchValue = '';
  sortValue = 0;
  page = 1;
  limit = 5;
  maxRecords = 1;

  constructor(private requestService: RequestService, private router: Router) {}

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    // Replace 'userId' with the actual user ID
    const userId = localStorage.getItem('userId');
    this.requestService.getRequestsByUserId(userId).subscribe(
      (response: any) => {
        this.userRequests = response;
        console.log('User requests:', this.userRequests);
        this.filteredRequests = response;
        this.maxRecords = response.length;
      },
      (error) => {
        console.error('Error fetching data:', error);
        // Handle error appropriately
      }
    );
  }

  totalPages(): number {
    return Math.ceil(this.maxRecords / this.limit);
  }

  filterRequests(): void {
    const searchLower = this.searchValue ? this.searchValue.toLowerCase() : '';
    if (searchLower === '') {
      this.filteredRequests = [...this.userRequests];
    } else {
      this.filteredRequests = this.userRequests.filter((request) =>
        request && request.RequestType && request.RequestType.toLowerCase().includes(searchLower)
      );
    }
    this.maxRecords = this.filteredRequests.length;
  }

  toggleSort(order: number): void {
    this.sortValue = order;

    this.filteredRequests.sort((a, b) => {
      return order === 1
        ? new Date(a.submissionDate).getTime() -
          new Date(b.submissionDate).getTime()
        : order === -1
        ? new Date(b.submissionDate).getTime() -
          new Date(a.submissionDate).getTime()
        : 0;
    });
  }

  handleDeleteClick(request: any): void {
    this.requestToDelete = request;
    this.showDeletePopup = true;
  }

  handleConfirmDelete(): void {
    this.requestService.deleteRequest(this.requestToDelete.RequestId).subscribe(
      (response) => {
        console.log('Request deleted successfully', response);
        this.fetchData();
        this.closeDeletePopup();
      },
      (error) => {
        console.error('Error deleting request:', error);
        // Handle error appropriately
      }
    );
  }

  closeDeletePopup(): void {
    this.requestToDelete = null;
    this.showDeletePopup = false;
  }

}
