import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Livestock } from 'src/app/models/livestock.model';
import { Request } from 'src/app/models/request.model';
import { LivestockService } from 'src/app/services/livestock.service';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-requestform',
  templateUrl: './requestform.component.html',
  styleUrls: ['./requestform.component.css']
})
export class RequestformComponent implements OnInit {

  @Input() selectedMedicine: any;
  @Input() selectedFeed: any;
  @Output() formSubmitted = new EventEmitter<void>();
  @Output() formCancelled = new EventEmitter<void>();

  medicationForm: FormGroup;
  errorMessage = "";
  feedName: any;
  medicineName: any;
  requestForm: FormGroup;
  availableLivestock: Livestock ;

  constructor(
    private fb: FormBuilder,
    private medicationService: RequestService,
    private livestockService: LivestockService,
  ) {
    this.medicationForm = this.fb.group({
      requestType: ['', Validators.required],
      // medicineId: ['', Validators.required],
      medicineName: [''],
      feedName: [''],
      userId: [Number(localStorage.getItem('userId')), Validators.required],
      livestockId: ['', Validators.required],
      quantity: ['', Validators.required],
      status: [''],
      requestDate: [''],
    });
  }

  ngOnInit(): void {
    console.log('Selected medicine:', this.selectedMedicine);


    if(this.selectedFeed) {
      this.feedName = true;
      this.medicationForm.patchValue({
        requestType: 'Feed', // Replace with actual request type
        feedId: this.selectedFeed.FeedId,
        feedName: this.selectedFeed.FeedName,
        // livestockId: 'YourLivestockId', // Replace with actual livestock ID
        quantity: 1, // Default quantity, can be changed by user
        status: 'Pending', // Default status, can be changed if needed
        requestDate: new Date().toISOString().split('T')[0], // Today's date
      });
    }

    if (this.selectedMedicine) {
      this.medicineName = true;
      this.medicationForm.patchValue({
        requestType: 'Medicine', // Replace with actual request type
        medicineId: this.selectedMedicine.MedicineId,
        medicineName: this.selectedMedicine.MedicineName,
        feedName: this.selectedMedicine.FeedName,
        // livestockId: 'YourLivestockId', // Replace with actual livestock ID
        quantity: 1, // Default quantity, can be changed by user
        status: 'Pending', // Default status, can be changed if needed
        requestDate: new Date().toISOString().split('T')[0], // Today's date
      });
    }
    const userId = parseInt(localStorage.getItem('userId') || '0', 10);
    this.livestockService.getLivestockByUserID(userId).subscribe(
      (data) => {
        console.log('Available livestock:', data);

        this.availableLivestock = data;
      },
      (error) => {
        console.error('Error fetching livestock:', error);
      }
    );
  }

  onSubmit(): void {
    if (this.medicationForm.valid) {
      const formData = this.medicationForm.value;
      const requestObject: Request = {
        RequestType: formData.requestType,
        MedicineId: Number(this.selectedMedicine?.MedicineId),
        FeedId: Number(this.selectedFeed?.FeedId),
        UserId: Number(localStorage.getItem('userId')),
        LivestockId: Number(formData.livestockId),
        Quantity: Number(formData.quantity),
        Status: 'Pending',
        RequestDate: formData.requestDate,
      };

      this.medicationService.addRequest(requestObject).subscribe(
        (response) => {
          console.log('Response:', response);
          this.formSubmitted.emit();
        },
        (error) => {
          console.error('Error submitting medication request:', error);
          this.errorMessage = 'Error submitting medication request. Please try again.';
        }
      );
    } else {
      this.errorMessage = "All fields are required";
    }
  }

  onCancel(): void {
    this.formCancelled.emit();
  }

}
