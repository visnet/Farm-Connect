import { Component, OnInit } from '@angular/core';
import { Feed } from 'src/app/models/feed.model';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FeedService } from 'src/app/services/feed.service';

@Component({
  selector: 'app-suppliereditfeed',
  templateUrl: './suppliereditfeed.component.html',
  styleUrls: ['./suppliereditfeed.component.css']
})
export class SuppliereditfeedComponent implements OnInit {

  id: string;
  errorMessage: string = '';
  formData: Feed = {
    FeedName: '',
    Type: '',
    Description: '',
    Quantity: null,
    Unit: '',
    PricePerUnit: null,
    Image: '',
    UserId: null
  };
  errors: any = {};
  successPopup: boolean; // Add this line to declare the successPopup property

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private feedService: FeedService
  ) {}

  ngOnInit(): void {
    console.log("Hello");
    this.id = this.route.snapshot.paramMap.get('id');
    this.getFeedById();
  }

  getFeedById() {
    this.feedService.getFeedById(this.id).subscribe(
      (response) => {
        console.log('Feed details:', response);
        this.formData = {
          FeedName: response.FeedName,
          Type: response.Type,
          Description: response.Description,
          Quantity: response.Quantity,
          Unit: response.Unit,
          PricePerUnit: response.PricePerUnit,
          Image: response.Image,
          UserId: response.UserId
        };
      },
      (error) => {
        console.error('Error fetching feed details:', error);
        this.router.navigate(['/error']);
      }
    );
  }

  handleChange(event: any, field: string) {
    this.formData[field] = event.target.value;
    this.errors[field] = ''; // Clear error when the user makes a change
  }

  handleUpdateFeed(feedForm: NgForm) {
    if (feedForm.valid) {
      this.feedService.updateFeed(this.id, this.formData).subscribe(
        (response) => {
          console.log('Feed updated successfully', response);
          this.successPopup = true;
          this.errorMessage = '';
        },
        (error) => {
          console.error('Error updating feed:', error);
          this.errorMessage = error.error.message;
        }
      );
    }
  }

  handleFileChange(event: any): void {
    const file = event.target.files[0];

    if (file) {
      this.convertFileToBase64(file).then(
        (base64String) => {
          this.formData.Image = base64String;
        },
        (error) => {
          console.error('Error converting file to base64:', error);
          // Handle error appropriately
        }
      );
    }
  }

  convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        resolve(reader.result as string);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  handleOkClick() {
    // Close the success popup
    this.successPopup = false;
    this.router.navigate(['/supplier/view/feed']);
  }

  navigateToDashboard() {
    this.router.navigate(['/supplier/view/feed']);
  }
}
