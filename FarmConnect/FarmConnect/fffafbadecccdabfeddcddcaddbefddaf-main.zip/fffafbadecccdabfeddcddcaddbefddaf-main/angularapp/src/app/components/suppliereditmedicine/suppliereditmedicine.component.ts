import { Component, OnInit } from '@angular/core';
import { Medicine } from 'src/app/models/medicine.model';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicineService } from 'src/app/services/medicine.service';

@Component({
  selector: 'app-suppliereditmedicine',
  templateUrl: './suppliereditmedicine.component.html',
  styleUrls: ['./suppliereditmedicine.component.css']
})
export class SuppliereditmedicineComponent implements OnInit {

  id: string;
  errorMessage: string = '';
  formData: Medicine = {
    MedicineName: '',
    Brand: '',
    Category: '',
    Description: '',
    Quantity: null,
    Unit: '',
    PricePerUnit: null,
    Image: '',
    UserId: null
  };
  errors: any = {};
  successPopup: boolean; // Add this line to declare the successPopup property

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private medicineService: MedicineService
  ) {}

  ngOnInit(): void {
    console.log("Hello");
    this.id = this.route.snapshot.paramMap.get('id');
    this.getMedicineById();
  }

  getMedicineById() {
    this.medicineService.getMedicineById(this.id).subscribe(
      (response) => {
        console.log('Medicine details:', response);
        this.formData = {
          MedicineName: response.MedicineName,
          Brand: response.Brand,
          Category: response.Category,
          Description: response.Description,
          Quantity: response.Quantity,
          Unit: response.Unit,
          PricePerUnit: response.PricePerUnit,
          Image: response.Image,
          UserId: response.UserId
        };
      },
      (error) => {
        console.error('Error fetching medicine details:', error);
        this.router.navigate(['/error']);
      }
    );
  }

  handleChange(event: any, field: string) {
    this.formData[field] = event.target.value;
    this.errors[field] = ''; // Clear error when the user makes a change
  }

  handleUpdateMedicine(medicineForm: NgForm) {
    if (medicineForm.valid) {
      this.medicineService.updateMedicine(this.id, this.formData).subscribe(
        (response) => {
          console.log('Medicine updated successfully', response);
          this.successPopup = true;
          this.errorMessage = '';
        },
        (error) => {
          console.error('Error updating medicine:', error);
          this.errorMessage = error.error.message;
        }
      );
    }
  }


  handleFileChange(event: any): void {
    const file = event.target.files[0];

    if (file) {
      this.convertFileToBase64(file).then(
        (base64String) => {
          this.formData.Image = base64String;
        },
        (error) => {
          console.error('Error converting file to base64:', error);
          // Handle error appropriately
        }
      );
    }
  }

  convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        resolve(reader.result as string);
      };

      reader.onerror = (error) => {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  handleOkClick() {
    // Close the success popup
    this.successPopup = false;
    this.router.navigate(['/supplier/view/medicine']);
  }

  navigateToDashboard() {
    this.router.navigate(['/supplier/view/medicine']);
  }
}
