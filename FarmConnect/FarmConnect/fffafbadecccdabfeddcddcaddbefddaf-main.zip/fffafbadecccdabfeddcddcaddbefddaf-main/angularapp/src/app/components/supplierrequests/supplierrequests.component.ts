import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestService } from 'src/app/services/request.service';

@Component({
  selector: 'app-supplierrequests',
  templateUrl: './supplierrequests.component.html',
  styleUrls: ['./supplierrequests.component.css']
})
export class SupplierrequestsComponent implements OnInit {
  showProfilePopup = false;
  selectedLiveStock = null;

  requests: any[] = [];
  searchValue = '';
  sortValue = 0;
  statusFilter = '-1';
  page = 1;
  pagesize = 2;
  maxPageLength = 0;
  maxRecords = 1;
  expandedRow: number | null = null;
  showModal = false;
  selectedRequest: any = null;
  filteredRequests = [];
  availableRequests: any[] = [];

  constructor(private requestService: RequestService, private router: Router) {}

  ngOnInit(): void {
    this.fetchData();
  }

  showProfile(user): void {
    this.selectedLiveStock = user;
    console.log('selectedUser:', this.selectedLiveStock);

    this.showProfilePopup = true;
  }

  closeProfilePopup(): void {
    this.showProfilePopup = false;
  }

  fetchData(): void {
    const userId = localStorage.getItem('userId');
    this.requestService.getRequestByMedicineOrFeedUserId(userId).subscribe(
      (response) => {
        this.requests = response;
        this.filteredRequests = [...this.requests];
        this.maxRecords = this.filteredRequests.length;
        // this.maxPageLength = Math.ceil(this.maxRecords / this.pagesize);
        console.log('requests:', this.requests);
        console.log('filteredRequests:', this.filteredRequests);

      },
      (error) => {
        console.error('Error fetching requests:', error);
        // Handle error appropriately
      }
    );
  }

  handleSearchChange(event: any): void {
    this.searchValue = event.target.value.toLowerCase();
    this.filteredRequests = this.requests.filter(request =>
      // request.Medicine && request.Medicine.MedicineName.toLowerCase().includes(this.searchValue)
      request.RequestType.toLowerCase().includes(this.searchValue)
    );
    this.maxRecords = this.filteredRequests.length;
    this.maxPageLength = Math.ceil(this.maxRecords / this.pagesize);
  }

  handleFilterChange(event: any): void {
    this.statusFilter = event.target.value;
    this.filteredRequests = this.requests.filter(request => {
      if (this.statusFilter === '-1') {
        // If the filter is set to 'All', return all requests
        return true;
      } else {
        // Otherwise, return only the requests that match the selected status
        return request.RequestStatus === parseInt(this.statusFilter, 10);
      }
    });
    this.maxRecords = this.filteredRequests.length;
    this.maxPageLength = Math.ceil(this.maxRecords / this.pagesize);
  }

  handleApprove(request: any): void {
    request.Status = "1";
    this.updateRequestStatus(request);
  }

  handleReject(request: any): void {
    request.Status = "2";
    this.updateRequestStatus(request);
  }

  updateRequestStatus(request: any): void {
    console.log('Updating request status:', request);
    const body = {
      RequestId: request.RequestId,
      RequestType: request.RequestType,
      FeedId: request.FeedId,
      MedicineId: request.MedicineId,
      UserId: request.UserId,
      User: request.User,
      LivestockId: request.LivestockId,
      Livestock: request.Livestock,
      Quantity: request.Quantity,
      Status: request.Status,
      RequestDate: request.RequestDate
    };

    this.requestService.updateRequestStatus(request.RequestId, body).subscribe(
      (response) => {
        console.log('Response:', response);
        this.fetchData();
      },
      (error) => {
        console.error('Error updating request status:', error);
        // Handle error appropriately
      }
    );
  }

  handleRowExpand(index: number): void {
    const selected = this.requests[index];
    console.log('selected:', selected);
    this.expandedRow = this.expandedRow === index ? null : index;
    this.selectedRequest = selected;
    this.showModal = !this.showModal;
  }

  closeRequestDetailsModal(): void {
    this.showModal = false;
  }

  handlePagination(direction: number): void {
    if (direction === -1 && this.page > 1) {
      this.page -= 1;
    } else if (direction === 1 && this.page < this.maxPageLength) {
      this.page += 1;
    }
    this.fetchData();
  }

}
