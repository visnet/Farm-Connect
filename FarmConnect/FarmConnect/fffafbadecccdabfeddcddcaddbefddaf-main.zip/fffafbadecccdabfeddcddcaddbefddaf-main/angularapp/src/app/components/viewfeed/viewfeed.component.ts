import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedService } from 'src/app/services/feed.service';

@Component({
  selector: 'app-viewfeed',
  templateUrl: './viewfeed.component.html',
  styleUrls: ['./viewfeed.component.css']
})
export class ViewfeedComponent implements OnInit {

  availableFeeds: any[] = [];
  showDeletePopup = false;
  feedToDelete: string | null = null;
  searchValue = '';
  sortValue = 0;
  page: number = 1;
  limit = 5;
  maxRecords = 1;
  totalPages = 1;
  status: string = '';
  filteredFeeds = [];
  searchField = '';
  errorMessage: string = '';
  allFeeds: any[] = [];
  showImageModal = false;
  selectedImage: string;

  constructor(private router: Router, private feedService: FeedService) {}

  ngOnInit(): void {
    this.fetchAvailableFeeds();
  }

  fetchAvailableFeeds() {
    const userId = Number(localStorage.getItem('userId')) || 0;
    this.feedService.getFeedByUserID(userId).subscribe(
      (data: any) => {
        this.availableFeeds = data;
        this.maxRecords = this.availableFeeds.length;
        this.allFeeds = data;
        this.totalPages = Math.ceil(this.maxRecords / this.limit);
        console.log('Available feeds:', this.availableFeeds);
      },
      (error) => {
        console.error('Error fetching feeds:', error);
      }
    );
  }

  handleDeleteClick(feedId: string) {
    this.feedToDelete = feedId;
    this.showDeletePopup = true;
  }

  navigateToEditFeed(id: string) {
    console.log('Navigating to edit feed:', id);
    this.router.navigate(['/supplier/edit/feed', id]);
  }

  handleConfirmDelete() {
    if (this.feedToDelete) {
      this.feedService.deleteFeed(this.feedToDelete).subscribe(
        (response) => {
          console.log('Feed deleted successfully', response);
          this.closeDeletePopup();
          this.fetchAvailableFeeds();
          this.errorMessage = '';
        },
        (error) => {
          console.error('Error deleting feed:', error);
          this.errorMessage = error.error.message;
        }
      );
    }
  }

  openImageModal(image: string) {
    this.selectedImage = image;
    this.showImageModal = true;
  }

  closeImageModal() {
    this.showImageModal = false;
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    localStorage.removeItem('userRole');
    this.router.navigate(['/login']);
  }

  closeDeletePopup() {
    this.feedToDelete = null;
    this.showDeletePopup = false;
    this.errorMessage = '';
  }

  updateAvailableFeeds(newFeeds: any[]) {
    this.availableFeeds = newFeeds;
  }

  handleSearchChange(searchValue: string): void {
    this.searchField = searchValue;
    if (searchValue) {
      this.availableFeeds = this.filterFeeds(searchValue);
    } else {
      this.availableFeeds = this.allFeeds;
    }
  }

  filterFeeds(search: string) {
    const searchLower = search.toLowerCase();
    if (searchLower === '') return this.availableFeeds;
    return this.availableFeeds.filter(
      (feed) =>
        feed.FeedName.toLowerCase().includes(searchLower) ||
        feed.Description.toLowerCase().includes(searchLower)
    );
  }
}
