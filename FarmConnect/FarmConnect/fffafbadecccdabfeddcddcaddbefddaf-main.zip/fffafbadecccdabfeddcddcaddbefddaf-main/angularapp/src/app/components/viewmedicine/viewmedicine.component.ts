import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicineService } from 'src/app/services/medicine.service';

@Component({
  selector: 'app-viewmedicine',
  templateUrl: './viewmedicine.component.html',
  styleUrls: ['./viewmedicine.component.css']
})
export class ViewmedicineComponent implements OnInit {

  availableMedicines: any[] = [];
  showDeletePopup = false;
  medicineToDelete: string | null = null;
  searchValue = '';
  sortValue = 0;
  page: number = 1;
  limit = 5;
  maxRecords = 1;
  totalPages = 1;
  status: string = '';
  filteredMedicines = [];
  searchField = '';
  errorMessage: string = '';
  allMedicines: any[] = [];
  showImageModal = false;
  selectedImage: string;


  constructor(private router: Router, private medicineService: MedicineService) {}

  ngOnInit(): void {
    this.fetchAvailableMedicines();
  }

  fetchAvailableMedicines() {
    const userId = Number(localStorage.getItem('userId')) || 0;
    this.medicineService.getMedicineByUserID(userId).subscribe(
      (data: any) => {
        this.availableMedicines = data;
        this.maxRecords = this.availableMedicines.length;
        this.allMedicines = data;
        this.totalPages = Math.ceil(this.maxRecords / this.limit);
        console.log('Available medicines:', this.availableMedicines);
      },
      (error) => {
        console.error('Error fetching medicines:', error);
      }
    );
  }

  handleDeleteClick(medicineId: string) {
    this.medicineToDelete = medicineId;
    this.showDeletePopup = true;
  }

  navigateToEditMedicine(id: string) {
    console.log('Navigating to edit medicine:', id);
    this.router.navigate(['/supplier/edit/medicine', id]);
  }

  handleConfirmDelete() {
    if (this.medicineToDelete) {
      this.medicineService.deleteMedicine(this.medicineToDelete).subscribe(
        (response) => {
          console.log('Medicine deleted successfully', response);
          this.closeDeletePopup();
          this.fetchAvailableMedicines();
          this.errorMessage = '';
        },
        (error) => {
          console.error('Error deleting medicine:', error);
          this.errorMessage = error.error.message;
        }
      );
    }
  }

  openImageModal(image: string) {
    this.selectedImage = image;
    this.showImageModal = true;
  }

  closeImageModal() {
    this.showImageModal = false;
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    localStorage.removeItem('userRole');
    this.router.navigate(['/login']);
  }

  closeDeletePopup() {
    this.medicineToDelete = null;
    this.showDeletePopup = false;
    this.errorMessage = '';
  }

  updateAvailableMedicines(newMedicines: any[]) {
    this.availableMedicines = newMedicines;
  }

  handleSearchChange(searchValue: string): void {
    this.searchField = searchValue;
    if (searchValue) {
      this.availableMedicines = this.filterMedicines(searchValue);
    } else {
      this.availableMedicines = this.allMedicines;
    }
  }

  filterMedicines(search: string) {
    const searchLower = search.toLowerCase();
    if (searchLower === '') return this.availableMedicines;
    return this.availableMedicines.filter(
      (medicine) =>
        medicine.MedicineName.toLowerCase().includes(searchLower) ||
        medicine.Description.toLowerCase().includes(searchLower)
    );
  }
}
