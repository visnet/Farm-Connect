import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feed } from '../models/feed.model';
import { apiUrl } from 'src/apiconfig';

@Injectable({
  providedIn: 'root'
})
export class FeedService {
  apiUrl = apiUrl;

  constructor(private http: HttpClient) {}

  // Methods Overview:
  // addFeed(requestObject: Feed): Observable<Feed>:
      // Use this method to add a new feed. It sends a POST request to the '/api/feed' endpoint with the feed data provided as the body and the authorization token prefixed with 'Bearer' stored in localStorage.
  // getFeedByUserID(id: number): Observable<Feed>:
  // This method is used to get a feed by the user ID. It sends a GET request to the '/api/feed/user/{id}' endpoint with the user ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
  // getFeedById(id: string): Observable<Feed>:
  // Use this method to get a feed by ID. It sends a GET request to the '/api/feed/{id}' endpoint with the feed ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
  // getAllFeed(): Observable<Feed[]>:
  // This method is used to get all feeds. It sends a GET request to the '/api/feed' endpoint with the authorization token prefixed with 'Bearer' stored in localStorage.
  // deleteFeed(feedId: string): Observable<void>:
  // Use this method to delete a feed. It sends a DELETE request to the '/api/feed/{feedId}' endpoint with the feed ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
  // updateFeed(id: string, requestObject: Feed): Observable<Feed>:
  // This method is used to update a feed. It sends a PUT request to the '/api/feed/{id}' endpoint with the feed ID provided as a parameter, the feed data provided as the body, and the authorization token prefixed with 'Bearer' stored in localStorage.



  addFeed(requestObject: Feed): Observable<Feed> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.post<Feed>(`${this.apiUrl}/api/feed`, requestObject, { headers });
  }

  getFeedByUserID(id: number): Observable<Feed> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Feed>(`${this.apiUrl}/api/feed/user/${id}`, { headers });
  }

  getFeedById(id: string): Observable<Feed> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Feed>(`${this.apiUrl}/api/feed/${id}`, { headers });
  }

  getAllFeed(): Observable<Feed[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Feed[]>(`${this.apiUrl}/api/feed`, { headers });
  }

  deleteFeed(feedId: string): Observable<void> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.delete<void>(`${this.apiUrl}/api/feed/${feedId}`, { headers });
  }

  updateFeed(id: string, requestObject: Feed): Observable<Feed> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.put<Feed>(`${this.apiUrl}/api/feed/${id}`, requestObject, { headers });
  }
}
