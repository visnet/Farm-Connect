import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrl } from 'src/apiconfig';
import { Livestock } from '../models/livestock.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LivestockService {
  public apiUrl = apiUrl; // Update with your API URL

  // Methods Overview:
// getAllLivestock(): Observable<Livestock[]>:
// Use this method to get all livestock. It sends a GET request to the '/api/livestock' endpoint with the authorization token prefixed with 'Bearer' stored in localStorage.
// getLivestockByUserID(id: number): Observable<Livestock>:
// This method is used to get livestock by the user ID. It sends a GET request to the '/api/livestock/user/{id}' endpoint with the user ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
// getLivestockByID(id: number): Observable<Livestock>:
// Use this method to get livestock by ID. It sends a GET request to the '/api/livestock/{id}' endpoint with the livestock ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
// addLivestock(livestock: Livestock): Observable<Livestock>:
// This method is used to add a new livestock. It sends a POST request to the '/api/livestock' endpoint with the livestock data provided as the body and the authorization token prefixed with 'Bearer' stored in localStorage.
// updateLivestock(id: number, livestock: Livestock): Observable<Livestock>:
// Use this method to update a livestock. It sends a PUT request to the '/api/livestock/{id}' endpoint with the livestock ID provided as a parameter, the livestock data provided as the body, and the authorization token prefixed with 'Bearer' stored in localStorage.
// deleteLivestock(id: number): Observable<void>:
// This method is used to delete a livestock. It sends a DELETE request to the '/api/livestock/{id}' endpoint with the livestock ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.



  constructor(private http: HttpClient) { }

  getAllLivestock(): Observable<Livestock[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Livestock[]>(`${this.apiUrl}/api/livestock`, { headers });
  }

  getLivestockByUserID(id: number): Observable<Livestock> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Livestock>(`${this.apiUrl}/api/livestock/user/${id}`, { headers });
  }

  getLivestockByID(id: number): Observable<Livestock> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Livestock>(`${this.apiUrl}/api/livestock/${id}`, { headers });
  }

  addLivestock(livestock: Livestock): Observable<Livestock> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.post<Livestock>(`${this.apiUrl}/api/livestock`, livestock, { headers });
  }

  updateLivestock(id: number, livestock: Livestock): Observable<Livestock> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.put<Livestock>(`${this.apiUrl}/api/livestock/${id}`, livestock, { headers });
  }

  deleteLivestock(id: number): Observable<void> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.delete<void>(`${this.apiUrl}/api/livestock/${id}`, { headers });
  }
}
