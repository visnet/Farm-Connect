import { Injectable } from '@angular/core';
import { Medicine } from '../models/medicine.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from 'src/apiconfig';

@Injectable({
  providedIn: 'root'
})
export class MedicineService {
  public apiUrl = apiUrl; // Update with your API URL

  // Methods Overview:
//   addMedicine(requestObject: Medicine): Observable<Medicine>:
//  // Use this method to add a new medicine. It sends a POST request to the '/api/medicine' endpoint with the medicine data provided as the body and the authorization token prefixed with 'Bearer' stored in localStorage.
//   getMedicineByUserID(id: number): Observable<Medicine>:
//   This method is used to get a medicine by the user ID. It sends a GET request to the '/api/medicine/user/{id}' endpoint with the user ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
//   getMedicineById(id: string): Observable<Medicine>:
//   Use this method to get a medicine by ID. It sends a GET request to the '/api/medicine/{id}' endpoint with the medicine ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
//   getAllMedicine(): Observable<Medicine[]>:
//   This method is used to get all medicines. It sends a GET request to the '/api/medicine' endpoint with the authorization token prefixed with 'Bearer' stored in localStorage.
//   deleteMedicine(medicineId: string): Observable<void>:
//   Use this method to delete a medicine. It sends a DELETE request to the '/api/medicine/{medicineId}' endpoint with the medicine ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
//   updateMedicine(id: string, requestObject: Medicine): Observable<Medicine>:
//   This method is used to update a medicine. It sends a PUT request to the '/api/medicine/{id}' endpoint with the medicine ID provided as a parameter, the medicine data provided as the body, and the authorization token prefixed with 'Bearer' stored in localStorage.

  constructor(private http: HttpClient) { }

  addMedicine(requestObject: Medicine): Observable<Medicine> {
    console.log('addMedicine', requestObject);
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.post<Medicine>(`${this.apiUrl}/api/medicine`, requestObject, { headers });
  }

  getMedicineByUserID(id: number): Observable<Medicine> {
      const headers = new HttpHeaders({
        'Authorization': 'Bearer ' + localStorage.getItem('token')
      });
      return this.http.get<Medicine>(`${this.apiUrl}/api/medicine/user/${id}`, { headers });
  }

  getMedicineById(id: string): Observable<Medicine> {
    console.log('getMedicineById', id);
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Medicine>(`${this.apiUrl}/api/medicine/${id}`, { headers });
  }


  getAllMedicine(): Observable<Medicine[]> {

    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Medicine[]>(`${this.apiUrl}/api/medicine`, { headers });
  }

  deleteMedicine(medicineId: string): Observable<void> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.delete<void>(`${this.apiUrl}/api/medicine/${medicineId}`, { headers });
  }

  updateMedicine(id: string, requestObject: Medicine): Observable<Medicine> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.put<Medicine>(`${this.apiUrl}/api/medicine/${id}`, requestObject, { headers });
  }
}
