import { Injectable } from '@angular/core';
import { Request } from '../models/request.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { apiUrl } from 'src/apiconfig';

@Injectable({
  providedIn: 'root'
})
export class RequestService {

  constructor(private http: HttpClient) { }
  public apiUrl = apiUrl; // Update with your API URL

  // Methods Overview:
// addRequest(request: Request): Observable<Request>:
// Use this method to add a new request. It sends a POST request to the '/api/request' endpoint with the request data provided as the body and the authorization token prefixed with 'Bearer' stored in localStorage.
// getRequestsByUserId(userId: string): Observable<Request[]>:
// This method is used to get requests by user ID. It sends a GET request to the '/api/request/user/{userId}' endpoint with the user ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
// deleteRequest(requestId: string): Observable<any>:
// Use this method to delete a request. It sends a DELETE request to the '/api/request/{requestId}' endpoint with the request ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
// getRequestByMedicineOrFeedUserId(userId: string): Observable<Request[]>:
// This method is used to get requests by medicines or feeds user ID (medicines or feeds). It sends a GET request to the '/api/request/user/{userId}/medicines-or-feeds' endpoint with the user ID provided as a parameter and the authorization token prefixed with 'Bearer' stored in localStorage.
// updateRequestStatus(requestId: number, status: Request): Observable<any>:
// Use this method to update a request status. It sends a PUT request to the '/api/request/{requestId}' endpoint with the request ID provided as a parameter, the request status provided as the body, and the authorization token prefixed with 'Bearer' stored in localStorage.


  addRequest(request: Request): Observable<Request> {
    console.log('addrequest', request);
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.post<Request>(`${this.apiUrl}/api/request`, request, { headers });
  }

  getRequestsByUserId(userId: string): Observable<Request[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Request[]>(`${this.apiUrl}/api/request/user/${userId}`, { headers });
  }

  deleteRequest(requestId: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.delete(`${this.apiUrl}/api/request/${requestId}`, { headers });
  }

  getRequestByMedicineOrFeedUserId(userId: string): Observable<Request[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<Request[]>(`${this.apiUrl}/api/request/user/${userId}/medicines-or-feeds`, { headers });
  }

  updateRequestStatus(requestId: number, status: Request): Observable<any> {
    console.log('updateRequestStatus', requestId, status);
    console.log(status.Status);
    console.log(status);



    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.put(`${this.apiUrl}/api/request/${requestId}`, status, { headers });
    // return this.http.put(`https://8080-fffafbadecccdabfeddcddcaddbefddaf.premiumproject.examly.io/api/request/2`,  status , { headers });
  }
}
