using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace dotnetapp.Controllers
{
    [Route("api/feed")]
    [ApiController]
    public class FeedController : ControllerBase
    {
        private readonly FeedService _feedService;

        public FeedController(FeedService feedService)
        {
            _feedService = feedService;
        }

        [Authorize]

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Feed>>> GetAllFeeds()
        {
            var feeds = await _feedService.GetAllFeeds();
            return Ok(feeds);
        }

        // [Authorize(Roles = "Admin")]

        [HttpGet("{feedId}")]
        public async Task<ActionResult<Feed>> GetFeedById(int feedId)
        {
            var feed = await _feedService.GetFeedById(feedId);

            if (feed == null)
                return NotFound(new { message = "Cannot find any feed" });

            return Ok(feed);
        }
     [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Feed>>> GetFeedsByUserId(int userId)
        {
            var feeds = await _feedService.GetFeedsByUserId(userId);
            if (feeds == null || !feeds.Any())
                return NotFound(new { message = "Cannot find any feeds for this user" });

            return Ok(feeds);
        }
        // [Authorize(Roles = "Admin")]

        [HttpPost]
        public async Task<ActionResult> AddFeed([FromBody] Feed feed)
        {
            try
            {
                var success = await _feedService.AddFeed(feed);
                if (success)
                    return Ok(new { message = "Feed added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add feed" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize(Roles = "Admin")]

        [HttpPut("{feedId}")]
        public async Task<ActionResult> UpdateFeed(int feedId, [FromBody] Feed feed)
        {
            try
            {
                var success = await _feedService.UpdateFeed(feedId, feed);

                if (success)
                    return Ok(new { message = "Feed updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any feed" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize(Roles = "Admin")]

        [HttpDelete("{feedId}")]
        public async Task<ActionResult> DeleteFeed(int feedId)
        {
            try
            {
                var success = await _feedService.DeleteFeed(feedId);

                if (success)
                    return Ok(new { message = "Feed deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any feed" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
