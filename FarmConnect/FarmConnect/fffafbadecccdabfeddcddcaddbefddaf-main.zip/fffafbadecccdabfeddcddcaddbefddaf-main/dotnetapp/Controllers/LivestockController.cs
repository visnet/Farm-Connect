using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace dotnetapp.Controllers
{
    [Route("api/livestock")]
    [ApiController]
    public class LivestockController : ControllerBase
    {
        private readonly LivestockService _livestockService;

        public LivestockController(LivestockService livestockService)
        {
            _livestockService = livestockService;
        }

        // [Authorize]

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Livestock>>> GetAllLivestocks()
        {
            var livestockList = await _livestockService.GetAllLivestocks();
            return Ok(livestockList);
        }

        // [Authorize(Roles = "Admin")]

        [HttpGet("{livestockId}")]
        public async Task<ActionResult<Livestock>> GetLivestockById(int livestockId)
        {
            var livestock = await _livestockService.GetLivestockById(livestockId);

            if (livestock == null)
                return NotFound(new { message = "Cannot find any livestock" });

            return Ok(livestock);
        }

        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Livestock>>> GetLivestocksByUserId(int userId)
        {
            var livestock = await _livestockService.GetLivestocksByUserId(userId);
            if (livestock == null)
                return NotFound(new { message = "No livestock found for this user" });

            return Ok(livestock);
        }

        // [Authorize(Roles = "Admin")]

        [HttpPost]
        public async Task<ActionResult> AddLivestock([FromBody] Livestock livestock)
        {
            try
            {
                var success = await _livestockService.AddLivestock(livestock);
                if (success)
                    return Ok(new { message = "Livestock added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add livestock" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize(Roles = "Admin")]

        [HttpPut("{livestockId}")]
        public async Task<ActionResult> UpdateLivestock(int livestockId, [FromBody] Livestock livestock)
        {
            try
            {
                var success = await _livestockService.UpdateLivestock(livestockId, livestock);

                if (success)
                    return Ok(new { message = "Livestock updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any livestock" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
      

        // [Authorize(Roles = "Admin")]

        [HttpDelete("{livestockId}")]
        public async Task<ActionResult> DeleteLivestock(int livestockId)
        {
            try
            {
                var success = await _livestockService.DeleteLivestock(livestockId);

                if (success)
                    return Ok(new { message = "Livestock deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any livestock" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
