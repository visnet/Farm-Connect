using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace dotnetapp.Controllers
{
    [Route("api/medicine")]
    [ApiController]
    public class MedicineController : ControllerBase
    {
        private readonly MedicineService _medicineService;

        public MedicineController(MedicineService medicineService)
        {
            _medicineService = medicineService;
        }

        // [Authorize]

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Medicine>>> GetAllMedicines()
        {
            var medicines = await _medicineService.GetAllMedicines();
            return Ok(medicines);
        }

        // [Authorize(Roles = "Admin")]

        [HttpGet("{medicineId}")]
        public async Task<ActionResult<Medicine>> GetMedicineById(int medicineId)
        {
            var medicine = await _medicineService.GetMedicineById(medicineId);

            if (medicine == null)
                return NotFound(new { message = "Cannot find any medicine" });

            return Ok(medicine);
        }

        // [Authorize(Roles = "Admin")]

        [HttpPost]
        public async Task<ActionResult> AddMedicine([FromBody] Medicine medicine)
        {
            try
            {
                var success = await _medicineService.AddMedicine(medicine);
                if (success)
                    return Ok(new { message = "Medicine added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add medicine" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize(Roles = "Admin")]

        [HttpPut("{medicineId}")]
        public async Task<ActionResult> UpdateMedicine(int medicineId, [FromBody] Medicine medicine)
        {
            try
            {
                var success = await _medicineService.UpdateMedicine(medicineId, medicine);

                if (success)
                    return Ok(new { message = "Medicine updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any medicine" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
        // [Authorize]
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Medicine>>> GetMedicinesByUserId(int userId)
        {
            var medicines = await _medicineService.GetMedicinesByUserId(userId);
            if (medicines == null)
                return NotFound(new { message = "Cannot find any medicines for this user" });

            return Ok(medicines);
        }
        

        // [Authorize(Roles = "Admin")]

        [HttpDelete("{medicineId}")]
        public async Task<ActionResult> DeleteMedicine(int medicineId)
        {
            try
            {
                var success = await _medicineService.DeleteMedicine(medicineId);

                if (success)
                    return Ok(new { message = "Medicine deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any medicine" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
