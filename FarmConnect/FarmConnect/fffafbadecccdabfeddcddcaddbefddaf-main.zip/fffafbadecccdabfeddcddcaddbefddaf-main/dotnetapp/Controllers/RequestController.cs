using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace dotnetapp.Controllers
{
    [Route("api/request")]
    [ApiController]
    public class RequestController : ControllerBase
    {
        private readonly RequestService _requestService;

        public RequestController(RequestService requestService)
        {
            _requestService = requestService;
        }

        // [Authorize]

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Request>>> GetAllRequests()
        {
            var requests = await _requestService.GetAllRequests();
            return Ok(requests);
        }

        // [Authorize]

        [HttpGet("{requestId}")]
        public async Task<ActionResult<Request>> GetRequestById(int requestId)
        {
            var request = await _requestService.GetRequestById(requestId);

            if (request == null)
                return NotFound(new { message = "Cannot find any request" });

            return Ok(request);
        }

        // [Authorize]

        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Request>>> GetRequestsByUserId(int userId)
        {
            var requests = await _requestService.GetRequestsByUserId(userId);

            if (requests == null || !requests.Any())
                return NotFound(new { message = "Cannot find any requests for the user" });

            return Ok(requests);
        }
        // [Authorize]

        [HttpGet("user/{userId}/medicines-or-feeds")]
        public async Task<ActionResult<IEnumerable<Request>>> GetRequestsByUserIdInMedicineOrFeed(int userId)
        {
            var requests = await _requestService.GetRequestsByUserIdInMedicineOrFeed(userId);

            if (requests == null || !requests.Any())
                return NotFound(new { message = "Cannot find any requests for the specified user" });

            return Ok(requests);
        }

        // [Authorize]

        [HttpPost]
        public async Task<ActionResult> AddRequest([FromBody] Request request)
        {
            try
            {
                var success = await _requestService.AddRequest(request);
                if (success)
                    return Ok(new { message = "Request added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add request" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize]

        [HttpPut("{requestId}")]
        public async Task<ActionResult> UpdateRequest(int requestId, [FromBody] Request request)
        {
            try
            {
                var success = await _requestService.UpdateRequest(requestId, request);

                if (success)
                    return Ok(new { message = "Request updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any request" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize]

        [HttpDelete("{requestId}")]
        public async Task<ActionResult> DeleteRequest(int requestId)
        {
            try
            {
                var success = await _requestService.DeleteRequest(requestId);

                if (success)
                    return Ok(new { message = "Request deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any request" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
