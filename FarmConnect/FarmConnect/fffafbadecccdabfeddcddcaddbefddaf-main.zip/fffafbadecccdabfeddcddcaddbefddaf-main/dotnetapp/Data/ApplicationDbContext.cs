﻿using dotnetapp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Data    
{
public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }
 
        public DbSet<Feedback> Feedbacks { get; set; }
         public  DbSet<User> Users { get; set; }
         public DbSet<Feed> Feeds { get; set; }
        public DbSet<Medicine> Medicines { get; set; }
        public DbSet<Request> Requests { get; set; }
        public DbSet<Livestock> Livestocks { get; set; }
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    base.OnModelCreating(modelBuilder);
            // Feed entity configuration
            modelBuilder.Entity<Feed>()
                .Property(f => f.Quantity)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Feed>()
                .Property(f => f.PricePerUnit)
                .HasColumnType("decimal(18,2)");

            // Medicine entity configuration
            modelBuilder.Entity<Medicine>()
                .Property(m => m.Quantity)
                .HasColumnType("decimal(18,2)");

            // Request entity configuration
            modelBuilder.Entity<Request>()
                .Property(r => r.Quantity)
                .HasColumnType("decimal(18,2)");

            // Livestock entity configuration
            modelBuilder.Entity<Livestock>()
                .Property(l => l.Age)
                .HasColumnType("int");

          modelBuilder.Entity<Livestock>()
                .HasOne(l => l.User)
                .WithMany()
                .HasForeignKey(l => l.UserId)
                .OnDelete(DeleteBehavior.Restrict);

}

}
}