using System;
using dotnetapp.Models;

namespace dotnetapp.Exceptions
{
public class LivestockException : Exception
{
    public LivestockException(string message) : base(message)
    {
    }
}

}