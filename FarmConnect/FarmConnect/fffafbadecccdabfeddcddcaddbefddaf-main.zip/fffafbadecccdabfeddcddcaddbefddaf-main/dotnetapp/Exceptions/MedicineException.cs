using System;
using dotnetapp.Models;

namespace dotnetapp.Exceptions
{
public class MedicineException : Exception
{
    public MedicineException(string message) : base(message)
    {
    }
}

}