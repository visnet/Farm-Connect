using System;
using dotnetapp.Models;

namespace dotnetapp.Exceptions
{
public class RequestException : Exception
{
    public RequestException(string message) : base(message)
    {
    }
}

}