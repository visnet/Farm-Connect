using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Feed
    {
        [Key]
        public int FeedId { get; set; } // Primary Key: Unique identifier for the feed. This field uniquely identifies each feed record in the table. It is required.

        [Required(ErrorMessage = "Feed name is required")]
        public string FeedName { get; set; } // Name of the feed. This field stores the name of the feed. It is required.

        [Required(ErrorMessage = "Type is required")]
        public string Type { get; set; } // Type or category of the feed (e.g., hay, grain, pellet). This field specifies the type or category of the feed. It is required.

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; } // Description of the feed. This field provides a description or information about the feed. It is required.

        [Required(ErrorMessage = "Quantity is required")]
        public int Quantity { get; set; } // Quantity of the feed available. This field represents the available quantity of the feed. It is required.

        [Required(ErrorMessage = "Unit is required")] 
        public string Unit { get; set; } 
        [Required(ErrorMessage = "Price per unit is required")]
        public decimal PricePerUnit { get; set; } // Price per unit of the feed. This field indicates the price of each unit of the feed. It is required.

        public string Image { get; set; } // URL to the image of the feed. This field stores the URL link to the image of the feed. It is optional.
    
        public int UserId { get; set; }
        public User? User { get; set; }

    }
}
