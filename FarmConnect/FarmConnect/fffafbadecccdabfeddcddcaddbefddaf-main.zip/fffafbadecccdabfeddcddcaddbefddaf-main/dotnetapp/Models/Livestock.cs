using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Livestock
    {
        [Key]
        public int LivestockId { get; set; } // Primary Key: Unique identifier for the livestock. This field uniquely identifies each livestock record in the table. It is required.

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; } // Name of the livestock. This field stores the name given to the livestock. It is required.

        [Required(ErrorMessage = "Species is required")]
        public string Species { get; set; } // Species of the livestock (e.g., cow, chicken, sheep). This field specifies the species to which the livestock belongs. It is required.

        [Required(ErrorMessage = "Age is required")]
        public int Age { get; set; } // Age of the livestock in months or years. This field represents the age of the livestock. It is required.

        [Required(ErrorMessage = "Breed is required")]
        public string Breed { get; set; } // Breed of the livestock. This field specifies the breed of the livestock. It is required.

        public string HealthCondition { get; set; } // Health condition of the livestock. This field describes the health condition of the livestock, including any relevant details. It is optional.

        [Required(ErrorMessage = "Location is required")]
        public string Location { get; set; } // Current location of the livestock (e.g., barn number, pasture). This field indicates the current physical location of the livestock. It is required.

        public string VaccinationStatus { get; set; } // Vaccination status of the livestock. This field stores information about the vaccination status of the livestock, such as vaccinated, pending vaccination, or not vaccinated. It is optional.
   
        public int UserId { get; set; }
        public User? User { get; set; }

    }
}
