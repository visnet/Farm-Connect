using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Medicine
    {
        [Key]
        public int MedicineId { get; set; } // Primary Key: Unique identifier for the medicine. This field uniquely identifies each medicine record in the table. It is required.

        [Required(ErrorMessage = "Medicine name is required")]
        public string MedicineName { get; set; } // Name of the medicine. This field stores the name of the medicine. It is required.

        public string Brand { get; set; } // Brand of the medicine. This field specifies the brand of the medicine. It is optional.

        [Required(ErrorMessage = "Category is required")]
        public string Category { get; set; } // Category of the medicine (e.g., antibiotic, vaccine). This field categorizes the medicine into different types. It is required.

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; } // Description of the medicine. This field provides a description or information about the medicine. It is required.

        [Required(ErrorMessage = "Quantity is required")]
        public int Quantity { get; set; } // Quantity of the medicine available. This field represents the available quantity of the medicine. It is required.

          [Required(ErrorMessage = "Unit is required")] 
        public string Unit { get; set; } // Price per unit of the medicine. This field indicates the price of each unit of the medicine. It is required.

        [Required(ErrorMessage = "Price per unit is required")] 
        public decimal PricePerUnit { get; set; } // Price per unit of the medicine. This field indicates the price of each unit of the medicine. It is required.

   
        [Required(ErrorMessage = "Image URL is required")]
        public string Image { get; set; } // URL to the image of the medicine. This field stores the URL link to the image of the medicine. It is required.
   
        public int UserId { get; set; }
        public User? User { get; set; }

    }
}
