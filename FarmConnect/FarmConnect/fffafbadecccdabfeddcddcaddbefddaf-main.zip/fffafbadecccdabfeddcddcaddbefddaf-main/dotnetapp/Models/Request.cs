using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace dotnetapp.Models
{
    public class Request
    {
        [Key]
        public int RequestId { get; set; } // Primary Key: Unique identifier for the request. This field uniquely identifies each request record in the table. It is required.

        [Required(ErrorMessage = "Request type is required")]
        public string RequestType { get; set; } // Type of request (e.g., medicine, feed). This field specifies the type of request being made. It is required.
        
        public int? FeedId { get; set; } // Identifier of the requested feed (related to the Feed Model). This field links the request to the specific feed it pertains to. It is optional.

        public Feed? Feed { get; set; } // Navigation property to the Feed model

        public int? MedicineId { get; set; } // Identifier of the requested medicine (related to the Medicine Model). This field links the request to the specific medicine it pertains to. It is optional.

        public Medicine? Medicine { get; set; } // Navigation property to the Medicine model


        [Required(ErrorMessage = "User ID is required")]
        [ForeignKey("User")]
        public int UserId { get; set; } // Identifier of the user making the request (related to the User Model). This field links the request to the user who made it. It is required.

        public User? User { get; set; } // Navigation property to the User model

        [ForeignKey("Livestock")]
        public int LivestockId { get; set; } // Identifier of the livestock related to the request (related to the Livestock Model). This field links the request to the specific livestock it pertains to. It is optional.

        public Livestock? Livestock { get; set; } // Navigation property to the Livestock model

        [Required(ErrorMessage = "Quantity is required")]
        public int Quantity { get; set; } // Quantity of the requested item. This field specifies the quantity of the item being requested. It is required.

        [Required(ErrorMessage = "Status is required")]
        public string Status { get; set; } // Status of the request (e.g., pending, accepted, rejected). This field indicates the current status of the request. It is required.

        [Required(ErrorMessage = "Request date is required")]
        public DateTime RequestDate { get; set; } // Date when the request was made. This field stores the date when the request was created. It is required.
    }
}
