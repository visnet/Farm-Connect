﻿namespace dotnetapp.Models
{
    public static class UserRoles
    {
        public const string Admin = "Owner";

        public const string User = "Supplier";
    }
}
