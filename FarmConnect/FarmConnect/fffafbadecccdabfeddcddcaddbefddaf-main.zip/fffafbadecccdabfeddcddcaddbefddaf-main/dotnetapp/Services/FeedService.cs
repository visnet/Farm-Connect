using dotnetapp.Data;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Exceptions;

namespace dotnetapp.Services
{
    public class FeedService
    {
        private readonly ApplicationDbContext _context;

        public FeedService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Feed>> GetAllFeeds()
        {
            return await _context.Feeds.ToListAsync();
        }

        public async Task<Feed> GetFeedById(int feedId)
        {
            return await _context.Feeds.FirstOrDefaultAsync(f => f.FeedId == feedId);
        }
         public async Task<IEnumerable<Feed>> GetFeedsByUserId(int userId)
        {
            return await _context.Feeds.Where(f => f.UserId == userId).ToListAsync();
        }

        public async Task<bool> AddFeed(Feed feed)
        {
            if (_context.Feeds.Any(f => f.FeedName == feed.FeedName))
            {
                throw new FeedException("Feed with the same name and type already exists");
            }
            _context.Feeds.Add(feed);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateFeed(int feedId, Feed feed)
        {
            var existingFeed = await _context.Feeds.FirstOrDefaultAsync(f => f.FeedId == feedId);

            if (existingFeed == null)
                return false;

            if (_context.Feeds.Any(f => f.FeedName == feed.FeedName && f.FeedId != feedId))
            {
                throw new FeedException("Feed with the same name and type already exists");
            }

            feed.FeedId = feedId;
            _context.Entry(existingFeed).CurrentValues.SetValues(feed);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteFeed(int feedId)
        {
            var feed = await _context.Feeds.FirstOrDefaultAsync(f => f.FeedId == feedId);
            if (feed == null)
                return false;

            if (_context.Requests.Any(r => r.RequestType == "feed" && r.FeedId == feed.FeedId))
            {
                throw new FeedException("Feed cannot be deleted, it is referenced in requests");
            }

            _context.Feeds.Remove(feed);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
