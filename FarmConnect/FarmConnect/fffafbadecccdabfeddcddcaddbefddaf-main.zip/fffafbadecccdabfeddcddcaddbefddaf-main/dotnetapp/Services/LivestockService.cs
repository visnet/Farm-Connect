using dotnetapp.Data;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Exceptions;

namespace dotnetapp.Services
{
    public class LivestockService
    {
        private readonly ApplicationDbContext _context;

        public LivestockService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Livestock>> GetAllLivestocks()
        {
            return await _context.Livestocks.ToListAsync();
        }

        public async Task<Livestock> GetLivestockById(int livestockId)
        {
            return await _context.Livestocks.FirstOrDefaultAsync(l => l.LivestockId == livestockId);
        }
        public async Task<IEnumerable<Livestock>> GetLivestocksByUserId(int userId)
        {
            return await _context.Livestocks.Where(l => l.UserId == userId).ToListAsync();
        }
        public async Task<bool> AddLivestock(Livestock livestock)
        {
            if (_context.Livestocks.Any(l => l.Name == livestock.Name && l.Breed == livestock.Breed && l.Species == livestock.Species))
            {
                throw new LivestockException("Livestock with the same name, breed, and species already exists");
            }
            _context.Livestocks.Add(livestock);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateLivestock(int livestockId, Livestock livestock)
        {
            var existingLivestock = await _context.Livestocks.FirstOrDefaultAsync(l => l.LivestockId == livestockId);

            if (existingLivestock == null)
                return false;

            if (_context.Livestocks.Any(l => l.Name == livestock.Name && l.Breed == livestock.Breed && l.Species == livestock.Species && l.LivestockId != livestockId))
            {
                throw new LivestockException("Livestock with the same name, breed, and species already exists");
            }

            livestock.LivestockId = livestockId;
            _context.Entry(existingLivestock).CurrentValues.SetValues(livestock);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteLivestock(int livestockId)
        {
            var livestock = await _context.Livestocks.FirstOrDefaultAsync(l => l.LivestockId == livestockId);
            if (livestock == null)
                return false;

            if (_context.Requests.Any(r => r.LivestockId == livestock.LivestockId))
            {
                throw new LivestockException("Livestock cannot be deleted, it is referenced in requests");
            }

            _context.Livestocks.Remove(livestock);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
