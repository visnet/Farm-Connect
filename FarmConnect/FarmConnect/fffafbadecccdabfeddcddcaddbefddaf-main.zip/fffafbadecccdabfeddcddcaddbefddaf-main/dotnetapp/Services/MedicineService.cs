using dotnetapp.Data;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Exceptions;

namespace dotnetapp.Services
{
    public class MedicineService
    {
        private readonly ApplicationDbContext _context;

        public MedicineService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Medicine>> GetAllMedicines()
        {
            return await _context.Medicines.ToListAsync();
        }

        public async Task<Medicine> GetMedicineById(int medicineId)
        {
            return await _context.Medicines.FirstOrDefaultAsync(m => m.MedicineId == medicineId);
        }
         public async Task<IEnumerable<Medicine>> GetMedicinesByUserId(int userId)
        {
            return await _context.Medicines
                                 .Where(m => m.UserId == userId)
                                 .ToListAsync();
        }

        public async Task<bool> AddMedicine(Medicine medicine)
        {
            if (_context.Medicines.Any(m => m.MedicineName == medicine.MedicineName && m.Brand == medicine.Brand))
            {
                throw new MedicineException("Medicine with the same name and brand already exists");
            }
            _context.Medicines.Add(medicine);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateMedicine(int medicineId, Medicine medicine)
        {
            var existingMedicine = await _context.Medicines.FirstOrDefaultAsync(m => m.MedicineId == medicineId);

            if (existingMedicine == null)
                return false;

            if (_context.Medicines.Any(m => m.MedicineName == medicine.MedicineName && m.Brand == medicine.Brand && m.MedicineId != medicineId))
            {
                throw new MedicineException("Medicine with the same name and brand already exists");
            }

            medicine.MedicineId = medicineId;
            _context.Entry(existingMedicine).CurrentValues.SetValues(medicine);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteMedicine(int medicineId)
        {
            var medicine = await _context.Medicines.FirstOrDefaultAsync(m => m.MedicineId == medicineId);
            if (medicine == null)
                return false;

            if (_context.Requests.Any(r => r.MedicineId == medicine.MedicineId))
            {
                throw new MedicineException("Medicine cannot be deleted, it is referenced in requests");
            }

            _context.Medicines.Remove(medicine);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
