using dotnetapp.Data;
using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Exceptions;

namespace dotnetapp.Services
{
    public class RequestService
    {
        private readonly ApplicationDbContext _context;

        public RequestService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Request>> GetAllRequests()
        {
            return await _context.Requests.Include(r => r.User).Include(r => r.Livestock).ToListAsync();
        }

        public async Task<Request> GetRequestById(int requestId)
        {
            return await _context.Requests.Include(r => r.User).Include(r => r.Livestock).FirstOrDefaultAsync(r => r.RequestId == requestId);
        }

        public async Task<IEnumerable<Request>> GetRequestsByUserId(int userId)
        {
            return await _context.Requests.Include(r => r.User).Include(r => r.Livestock).Include(r => r.Medicine).Include(r => r.Feed)
                .Where(r => r.UserId == userId).ToListAsync();
        }

         public async Task<IEnumerable<Request>> GetRequestsByUserIdInMedicineOrFeed(int userId)
        {
            return await _context.Requests
                .Include(r => r.Medicine)
                .Include(r => r.Feed).Include(r => r.Livestock)
                .Where(r => (r.Medicine != null && r.Medicine.UserId == userId) ||
                            (r.Feed != null && r.Feed.UserId == userId))
                .ToListAsync();
        }

        public async Task<bool> AddRequest(Request request)
        {
            _context.Requests.Add(request);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateRequest(int requestId, Request request)
        {
            var existingRequest = await _context.Requests.FirstOrDefaultAsync(r => r.RequestId == requestId);

            if (existingRequest == null)
                return false;

            request.RequestId = requestId;
            _context.Entry(existingRequest).CurrentValues.SetValues(request);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteRequest(int requestId)
        {
            var request = await _context.Requests.FirstOrDefaultAsync(r => r.RequestId == requestId);
            if (request == null)
                return false;

            _context.Requests.Remove(request);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
